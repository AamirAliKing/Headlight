package com.example.retailoclient.Models;

import android.graphics.Bitmap;

public class SubProducts {
    Bitmap imgSubProduct;
    String subProductName;
    String brand;
    int subProductQuantity;
    int price;

    public SubProducts(Bitmap imgSubProduct,String subProductName,String brand, int subProductQuantity, int price) {
        this.imgSubProduct=imgSubProduct;
        this.subProductName = subProductName;
        this.subProductQuantity = subProductQuantity;
        this.price = price;
        this.brand=brand;
    }

    public String getSubProductName() {
        return subProductName;
    }

    public void setSubProductName(String subProductName) {
        this.subProductName = subProductName;
    }

    public int getSubProductQuantity() {
        return subProductQuantity;
    }

    public void setSubProductQuantity(int subProductQuantity) {
        this.subProductQuantity = subProductQuantity;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public Bitmap getImgSubProduct() {
        return imgSubProduct;
    }

    public void setImgSubProduct(Bitmap imgSubProduct) {
        this.imgSubProduct = imgSubProduct;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }
}
