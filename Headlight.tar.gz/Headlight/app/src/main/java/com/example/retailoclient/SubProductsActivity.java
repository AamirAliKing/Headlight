package com.example.retailoclient;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.app.ProgressDialog;
import android.app.SearchManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.SearchView;
import android.widget.TextView;
import android.widget.Toast;
import com.android.volley.AuthFailureError;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.retailoclient.Adapters.SubProductAdaptor;
import com.example.retailoclient.Models.CartProduct;
import com.example.retailoclient.Models.SubProducts;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class SubProductsActivity extends AppCompatActivity {


    RecyclerView recyclerView;
    List<SubProducts> mSubProducts;
    SubProductAdaptor subProductAdaptor;
    TextView txtBrand;
    static TextView txtcartitemcount;
    FloatingActionButton btnCartHistory;
    public Menu menu;
    static String cartitemscount="0";
    public static String catnam;

    public static List<CartProduct> cartSubProducts = new ArrayList<CartProduct>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sub_products);

        // adding custom toolbar in app
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowTitleEnabled(false);

        btnCartHistory = (FloatingActionButton) findViewById(R.id.btnCartHistoryInProducts);
        txtBrand = (TextView) findViewById(R.id.txt_brand_label);
        txtcartitemcount = (TextView) findViewById(R.id.txt_item_count_inproducts);

        // these line are done for setting carted items number on floating action button

        catnam = getIntent().getStringExtra("category");
        txtBrand.setText(catnam + "");

        mSubProducts = new ArrayList<SubProducts>();

        retrieveDataFromServer();
        getCartItemscount(getApplicationContext());

        recyclerView = (RecyclerView) findViewById(R.id.recycler2);
        subProductAdaptor = new SubProductAdaptor(mSubProducts);
        recyclerView.setHasFixedSize(true);
        recyclerView.setAdapter(subProductAdaptor);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        btnCartHistory.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(SubProductsActivity.this, CartActivity.class);
                intent.putExtra("category",catnam);
                startActivity(new Intent(SubProductsActivity.this, CartActivity.class));
                finish();
            }
        });

    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        this.menu = menu;

        SearchManager searchManager = (SearchManager) getSystemService(SEARCH_SERVICE);
        SearchView searchView = (SearchView) menu.findItem(R.id.app_bar_search).getActionView();
        searchView.setSearchableInfo(searchManager.getSearchableInfo(getComponentName()));
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {

                Toast.makeText(getApplicationContext(), query, Toast.LENGTH_SHORT).show();
                retrieveDataFromServer(query);

                return true;
            }

            @Override
            public boolean onQueryTextChange(String newText) {

                if (newText.equals("")) {

                    retrieveDataFromServer();
                }
                return true;
            }
        });


        return true;
    }

    public void retrieveDataFromServer() {
        mSubProducts.clear();
        final ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("loading data");
        progressDialog.show();

        StringRequest stringRequest = new StringRequest(StringRequest.Method.POST, "http://headlight.pk/test/getProducts.php",
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        progressDialog.dismiss();
                        try {


                            JSONObject jsonObject = new JSONObject(response);
                            JSONArray jsonArray = jsonObject.getJSONArray("data");

                            for (int x = 0; x < jsonArray.length(); x++) {

                                JSONObject jsonObject2 = jsonArray.getJSONObject(x);
                                String subProductName = jsonObject2.getString("productname");
                                String subProductBrand = jsonObject2.getString("catname");
                                int subProductqty = jsonObject2.getInt("productqty");
                                int subProductprice = jsonObject2.getInt("productprice");

                                String encodedImage = jsonObject2.getString("productimg");
                                byte[] decodedString = Base64.decode(encodedImage, Base64.DEFAULT);
                                BitmapFactory.Options options=new BitmapFactory.Options();
                                options.outWidth=320;
                                options.outHeight=480;
                                Bitmap bitmap = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length,options);

                                //Log.d("results", subProductBrand+" : "+subProductName+" : "+subProductprice+" : "+subProductqty+" : "+mSubProducts.size());
                                mSubProducts.add(new SubProducts(bitmap, subProductName, subProductBrand, subProductqty, subProductprice));
                                subProductAdaptor.notifyDataSetChanged();
                            }

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                Toast.makeText(getApplicationContext(), "error in loading" + "", Toast.LENGTH_SHORT).show();

            }
        }) {

            @Override
            protected Map<String, String> getParams() throws AuthFailureError {

                Map<String, String> params = new HashMap<String, String>();
                params.put("category", catnam);
                return params;

            }
        };


        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);

    }


    public void retrieveDataFromServer(final String query) {

        mSubProducts.clear();
        final ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("loading data");
        progressDialog.show();

        StringRequest stringRequest = new StringRequest(StringRequest.Method.POST, "http://headlight.pk/test/search2.php",
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        progressDialog.dismiss();
                        try {

                            JSONObject jsonObject = new JSONObject(response);
                            JSONArray jsonArray = jsonObject.getJSONArray("data");

                          //  Log.d("search: ",jsonObject.toString());
                            for (int x = 0; x < jsonArray.length(); x++) {

                                JSONObject jsonObject2 = jsonArray.getJSONObject(x);
                        //        Log.d("search: ",jsonObject2.toString());

                                String subProductName = jsonObject2.getString("productname");
                                String subProductBrand = jsonObject2.getString("catname");
                                int subProductqty = jsonObject2.getInt("productqty");
                                int subProductprice = jsonObject2.getInt("productprice");

                                String encodedImage = jsonObject2.getString("productimg");
                                byte[] decodedString = Base64.decode(encodedImage, Base64.DEFAULT);
                                BitmapFactory.Options options=new BitmapFactory.Options();
                                options.outWidth=320;
                                options.outHeight=480;
                                Bitmap bitmap = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length,options);

//                                Log.d("results3", subProductBrand+" : "+subProductName+" : "+subProductprice+" : "+subProductqty+" : "+mSubProducts.size());

                                mSubProducts.add(new SubProducts(bitmap, subProductName, subProductBrand, subProductqty, subProductprice));
                                subProductAdaptor.notifyDataSetChanged();
                            }

                        } catch (JSONException e) {
                            progressDialog.dismiss();
//                            Log.d("error0",e.toString());
                            e.getMessage();
                        }

                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.d( "error0: ",error.toString());
                progressDialog.dismiss();
                Toast.makeText(getApplicationContext(), "error in loading" + "", Toast.LENGTH_SHORT).show();
            }
        }) {

            @Override
            protected Map<String, String> getParams() throws AuthFailureError {

                Map<String, String> params = new HashMap<String, String>();
                params.put("catname", catnam);
                params.put("productname", query);
                return params;

            }
        };


        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);

    }


    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        int id = item.getItemId();

        switch (id) {

            case R.id.app_bar_logout:

                Toast.makeText(getApplicationContext(), "loging out", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(SubProductsActivity.this, LoginActivity.class));
                finish();

                break;

            case R.id.app_bar_refresh:

                retrieveDataFromServer();

                break;

        }

        return true;
    }

   public static void getCartItemscount(Context context){

        StringRequest stringRequest= new StringRequest(StringRequest.Method.POST, "http://headlight.pk/test/countcartitems.php", new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                cartitemscount=response.toString();
                txtcartitemcount.setText(cartitemscount+"");
            }

        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        }){

            @Override
            protected Map<String, String> getParams() throws AuthFailureError {

                Map<String,String> params=new HashMap<String, String>();
                params.put("username",ProductsActivity.name);

                return params;
            }
        };

        RequestQueue requestQueue=Volley.newRequestQueue(context);
        requestQueue.add(stringRequest);

    }

    @Override
    protected void onResume() {
        super.onResume();
        getCartItemscount(getApplicationContext());
    }
}