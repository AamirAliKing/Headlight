package com.example.retailoclient.Models;

import android.graphics.Bitmap;

public class CartProduct {

    String orderid;
    Bitmap productimg;
    String productname;
    String catname;
    int productQty;
    int productPrice;
    String status;

    public CartProduct(String orderid, Bitmap productimg, String productname, String catname, int productQty, int productPrice, String status) {
        this.orderid = orderid;
        this.productimg = productimg;
        this.productname = productname;
        this.catname = catname;
        this.productQty = productQty;
        this.productPrice = productPrice;
        this.status = status;
    }

    public String getOrderid() {
        return orderid;
    }

    public void setOrderid(String orderid) {
        this.orderid = orderid;
    }

    public Bitmap getProductimg() {
        return productimg;
    }

    public void setProductimg(Bitmap productimg) {
        this.productimg = productimg;
    }

    public String getProductname() {
        return productname;
    }

    public void setProductname(String productname) {
        this.productname = productname;
    }

    public String getCatname() {
        return catname;
    }

    public void setCatname(String catname) {
        this.catname = catname;
    }

    public int getProductQty() {
        return productQty;
    }

    public void setProductQty(int productQty) {
        this.productQty = productQty;
    }

    public int getProductPrice() {
        return productPrice;
    }

    public void setProductPrice(int productPrice) {
        this.productPrice = productPrice;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
