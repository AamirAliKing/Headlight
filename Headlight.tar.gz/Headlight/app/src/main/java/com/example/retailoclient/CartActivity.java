package com.example.retailoclient;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.retailoclient.Adapters.CartAdaptor;
import com.example.retailoclient.Models.CartProduct;
import com.example.retailoclient.Models.SubProducts;
import com.google.android.material.snackbar.Snackbar;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CartActivity extends AppCompatActivity {

    public static List<CartProduct> mcartProducts;
    public static CartAdaptor cartAdaptor;
    RecyclerView cartListrecyler;
    static int totalPrice=0;
    static String orderid="";
    public static String status="";
    static Date date = new Date();
    static String stringDate = DateFormat.getDateTimeInstance().format(date);
    static TextView txtName;
    String catname;
    static TextView txtOrderStatus;
    static TextView txtCellNo;
    static TextView txtOrderno;
    static TextView txtcartorderDate;
    static TextView txtOrderDeliveryDate;
    static TextView txtPaymentMethod;
    static TextView txtTotalAmount;
    static TextView txtUserId;
    TextView txtOrderdate;
    Button btnBuyConfirm;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cart);

        catname=getIntent().getStringExtra("category");

        txtName=(TextView)findViewById(R.id.txt_cart_username);
        txtCellNo=(TextView)findViewById(R.id.txt_cart_mobileno);
        txtOrderno=(TextView)findViewById(R.id.txt_cart_orderno);
        txtOrderdate=(TextView)findViewById(R.id.txt_order_date);
        txtcartorderDate=(TextView)findViewById(R.id.txt_cart_order_date);
        txtOrderDeliveryDate=(TextView)findViewById(R.id.txt_delivery_date);
        txtPaymentMethod=(TextView)findViewById(R.id.txt_payment_method);
        txtTotalAmount=(TextView)findViewById(R.id.txt_total_amount);
        txtOrderStatus=(TextView)findViewById(R.id.txt_order_status) ;
        txtUserId=(TextView)findViewById(R.id.txt_order_id);
        btnBuyConfirm=(Button)findViewById(R.id.btn_buy_confirm);

        txtName.setText(ProductsActivity.name);
        txtCellNo.setText(ProductsActivity.number+"");

        mcartProducts=new ArrayList<CartProduct>();

        getFromCart(CartActivity.this);

        txtOrderdate.setText(stringDate);

        cartListrecyler=(RecyclerView)findViewById(R.id.recycler3);
        cartAdaptor=new CartAdaptor(mcartProducts);
        cartListrecyler.setHasFixedSize(true);
        cartListrecyler.setAdapter(cartAdaptor);
        cartListrecyler.setLayoutManager(new LinearLayoutManager(this));


        btnBuyConfirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (!(mcartProducts.size()==0)) {
                    txtcartorderDate.setText(stringDate);
                    txtOrderDeliveryDate.setText("Within 2 days");
                    ProgressDialog progressDialog = new ProgressDialog(CartActivity.this);
                    progressDialog.setMessage("confirming, please wait");
                    progressDialog.setCancelable(false);
                    progressDialog.show();
                    for (CartProduct cartProduct : mcartProducts) {

                        setReserved(ProductsActivity.name, cartProduct.getProductname());
                    }
                    progressDialog.dismiss();

                    Snackbar.make(btnBuyConfirm, "Order will be Delivered within 2 days", Snackbar.LENGTH_LONG)
                            .setAction("Action", null).show();

                    getFromCart(CartActivity.this);
                    txtOrderStatus.setText(status);

                }else {

                    Snackbar.make(btnBuyConfirm, "You haven't selected any item yet", Snackbar.LENGTH_LONG)
                            .setAction("Action", null).show();
                }
            }
        });
    }


    public static void getFromCart(final Context context){

        totalPrice=0;
        mcartProducts.clear();

        final ProgressDialog progressDialog=new ProgressDialog(context);
        progressDialog.setMessage("please wait");
        progressDialog.show();

        StringRequest stringRequest= new StringRequest(StringRequest.Method.POST, "http://headlight.pk/test/getFromCart.php", new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                Log.d("results", response.toString()+"");
                try {

                    progressDialog.dismiss();
                    JSONObject jsonObject = new JSONObject(response);
                    JSONArray jsonArray=jsonObject.getJSONArray("data");
                    Log.d("results1", jsonArray.toString()+"");

                    for (int x=0; x<jsonArray.length(); x++){

                        JSONObject jsonObject2=jsonArray.getJSONObject(x);

                        orderid=jsonObject2.getString("orderid");
                        String productName=jsonObject2.getString("productname");
                        String productBrand=jsonObject2.getString("catname");
                        int productqty=jsonObject2.getInt("productqty");
                        int productprice=jsonObject2.getInt("productprice");
                        status=jsonObject2.getString("status");

                        totalPrice+=productprice;

                        String encodedImage=jsonObject2.getString("productimg");
                        byte[] decodedString = Base64.decode(encodedImage, Base64.DEFAULT);
                        Bitmap bitmap = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);

                        Log.d("results", productBrand+" : "+productName+" : "+productBrand+" : "+productqty+" : "+productprice+"  : "+status);

                        mcartProducts.add(new CartProduct(orderid,ProductsActivity.imgesForCartList.get(productName),productName,productBrand,productqty,productprice,status));
                        cartAdaptor.notifyDataSetChanged();

                        txtOrderStatus.setText(status);
                        if (status.equals("reserved")) {
                            txtOrderno.setText(orderid + "");
                            txtcartorderDate.setText(stringDate + "");
                            txtUserId.setText(orderid + "");
                            txtOrderDeliveryDate.setText("Delivery within 2 days");
                        }
                    }

                }catch (JSONException e){

                    progressDialog.dismiss();
                    e.printStackTrace();
                }

                txtTotalAmount.setText("Rs : "+totalPrice);
            }

        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                progressDialog.dismiss();
                Toast.makeText(context.getApplicationContext(),"Something went wrong",Toast.LENGTH_SHORT).show();
            }
        }){

            @Override
            protected Map<String, String> getParams() throws AuthFailureError {

                Map<String,String> params=new HashMap<String, String>();
                params.put("username",ProductsActivity.name);

                return params;
            }
        };

        RequestQueue requestQueue=Volley.newRequestQueue(context);
        requestQueue.add(stringRequest);
    }

    private void setReserved(String name, final String productname) {

        StringRequest stringRequest= new StringRequest(StringRequest.Method.POST, "http://headlight.pk/test/reserve.php", new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                Toast.makeText(getApplicationContext(),response.toString(),Toast.LENGTH_SHORT).show();
            }

        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                Toast.makeText(getApplicationContext(),"Something went wrong",Toast.LENGTH_SHORT).show();
            }
        }){

            @Override
            protected Map<String, String> getParams() throws AuthFailureError {

                Map<String,String> params=new HashMap<String, String>();
                params.put("username",ProductsActivity.name);
                params.put("productname",productname);

                return params;
            }
        };

        RequestQueue requestQueue=Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);

    }

    @Override
    public void onBackPressed() {
        Intent intent=new Intent(CartActivity.this,ProductsActivity.class);
        intent.putExtra("category",catname);
        startActivity(intent);
        finish();

    }
}
