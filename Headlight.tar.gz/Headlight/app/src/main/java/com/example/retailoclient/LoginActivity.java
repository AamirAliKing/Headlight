package com.example.retailoclient;

import androidx.appcompat.app.AppCompatActivity;

import android.app.PendingIntent;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.IntentSender;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.gms.auth.api.credentials.Credential;
import com.google.android.gms.auth.api.credentials.Credentials;
import com.google.android.gms.auth.api.credentials.HintRequest;
import com.google.android.material.snackbar.Snackbar;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class LoginActivity extends AppCompatActivity {

    EditText etNumberLogin,etPasswordLogin;
    Button btnLogin, btnForgotPass, btnSignupLogin;
    String number;
    String password;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        etNumberLogin=(EditText)findViewById(R.id.et_number_login);
        etPasswordLogin=(EditText)findViewById(R.id.et_password_login);

        btnLogin=(Button)findViewById(R.id.btn_login);
        btnForgotPass=(Button)findViewById(R.id.btn_forgot_pass);
        btnSignupLogin=(Button)findViewById(R.id.btn_signup_in_login);

        // verify user number
        numberCheckin();

        //Reseting password
        btnForgotPass.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!((etNumberLogin.getText().toString()).isEmpty())){

                    Intent intent=new Intent(LoginActivity.this,ForgotPasswordActivity.class);
                    intent.putExtra("number",number);
                    startActivity(intent);
            }else {

                    Snackbar.make(btnForgotPass, "Enter your phone number", Snackbar.LENGTH_LONG)
                            .setAction("Action", null).show();
                }
            }
        });

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (etNumberLogin.getText().toString().isEmpty()) {
                    etNumberLogin.setError("Enter the number");
                } else {
                    if (etPasswordLogin.getText().toString().isEmpty()) {
                        etPasswordLogin.setError("Enter the Password");
                    } else {
                        login(etNumberLogin.getText().toString() + "", etPasswordLogin.getText().toString() + "");
                        etNumberLogin.setText("");
                        etPasswordLogin.setText("");
                    }
                }
            }

        });


        btnSignupLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(LoginActivity.this,SignupActivity.class));
            }
        });
    }

    // Checking on database for login credientials
    public void login(final String cellno, final String password){

        final ProgressDialog progressDialog =new ProgressDialog(this);
        progressDialog.setMessage("please wait");
        progressDialog.show();
        StringRequest loginRequest=new StringRequest(StringRequest.Method.POST, "http://headlight.pk/test/login2.php", new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                         JSONObject jsonObject=new JSONObject(response);
                         JSONArray jsonArray=jsonObject.getJSONArray("data");
                         Log.d( "resultt: ",jsonObject.toString());
                         String username =jsonArray.getJSONObject(0).getString("username");
                         String numberr=jsonArray.getJSONObject(0).getString("cellno");

                         if (!numberr.isEmpty()) {
                                progressDialog.dismiss();
                                Intent intent = new Intent(LoginActivity.this, ProductsActivity.class);
                                intent.putExtra("name", username);
                                intent.putExtra("number", numberr);
                                startActivity(intent);
                                finish();
                            }

                } catch (JSONException e) {
                    Log.d( "error: ",e.toString());
                    progressDialog.dismiss();
                    Toast.makeText(getApplicationContext(),"failed",Toast.LENGTH_SHORT).show();
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                progressDialog.dismiss();
                Log.d("error2", error.toString());
                Toast.makeText(getApplicationContext(),"Network problem",Toast.LENGTH_SHORT).show();
            }
        }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {

                Map<String,String> params=new HashMap<String, String>();
                params.put("cellno",cellno);
                params.put("password",password);

                return params;
            }
        };

        RequestQueue signUpRequesQueue= Volley.newRequestQueue(this);
        signUpRequesQueue.add(loginRequest);
    }

    private void numberCheckin() {
        HintRequest hintRequest = new HintRequest.Builder()
                .setPhoneNumberIdentifierSupported(true)
                .build();

        PendingIntent intent = Credentials.getClient(this).getHintPickerIntent(hintRequest);
        try {
            startIntentSenderForResult(intent.getIntentSender(),
                    1, null, 0, 0, 0);
        } catch (IntentSender.SendIntentException e) {
            e.printStackTrace();
        }
}

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode) {
            case 1:
                // Obtain the phone number from the result
                if (resultCode == RESULT_OK) {
                    Credential credential = data.getParcelableExtra(Credential.EXTRA_KEY);

                    number = credential.getId().toString();
                    number="0"+number.substring(3);
                    etNumberLogin.setText(number);
                }
                break;
            // ...
        }
    }

    @Override
    public void onBackPressed() {

    }
}