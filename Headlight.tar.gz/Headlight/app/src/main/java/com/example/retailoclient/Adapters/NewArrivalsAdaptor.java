package com.example.retailoclient.Adapters;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.retailoclient.Models.Product;
import com.example.retailoclient.R;
import com.example.retailoclient.SubProductsActivity;

import java.util.List;

public class NewArrivalsAdaptor extends RecyclerView.Adapter<NewArrivalsAdaptor.ViewHolder> {
        List<Product> mProducts;

        public NewArrivalsAdaptor(List<Product> mProducts) {
            this.mProducts = mProducts;
        }

        public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
            Context context;
            ImageView imgProduct;
            TextView txtProduct;

            public ViewHolder(Context context, View itemView) {

                super(itemView);
                this.context=context;
                imgProduct=(ImageView)itemView.findViewById(R.id.img_product_arrival);
                txtProduct=(TextView) itemView.findViewById(R.id.txt_product_arrival);

                itemView.setOnClickListener(this);
            }


            @Override
            public void onClick(View v) {
                int pos=getAdapterPosition();
                Toast.makeText(context.getApplicationContext(),  mProducts.get(pos).getProductName(),Toast.LENGTH_SHORT).show();
                Intent intent=new Intent(context, SubProductsActivity.class);
                //Intent intent=new Intent("com.example.retailoclient.SubProductsActivity");
                intent.putExtra("category",mProducts.get(pos).getProductName());

                context.startActivity(intent);
            }
        }


    @Override
    public NewArrivalsAdaptor.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View rowView= LayoutInflater.from(parent.getContext()).inflate(R.layout.newarrival_row,parent,false);
        ViewHolder viewHolder=new ViewHolder(parent.getContext(),rowView);

        return viewHolder;
    }

    @Override
        public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
            ImageView imgProduct=holder.imgProduct;
            TextView txtProduct=holder.txtProduct;

            imgProduct.setImageBitmap(mProducts.get(position).getProductImg());
            txtProduct.setText(mProducts.get(position).getProductName());
        }

        @Override
        public int getItemCount() {
            return mProducts.size();
        }

    }


