package com.example.retailoclient;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.widget.ImageView;
import android.widget.ProgressBar;

public class SplashScreenActivity extends Activity {

    ProgressBar progressBar;
    ImageView splashImage;
    int progress=0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_screen);

        progressBar=(ProgressBar)findViewById(R.id.progressBar);
        splashImage=(ImageView)findViewById(R.id.splashscreen);
        splashImage.setScaleX(0.2f);
        splashImage.setScaleY(0.2f);
        splashImage.setScaleType(ImageView.ScaleType.FIT_XY);
        splashImage.animate().alpha(1).scaleX(1).scaleY(1).setDuration(1000);


        new Handler().postDelayed(new Runnable(){
            @Override
            public void run() {

                /* Create an Intent that will start the Menu-Activity. */
                Intent mainIntent = new Intent(SplashScreenActivity.this,LoginActivity.class);
                startActivity(mainIntent);
                finish();
            }
        }, 800);
    }

}