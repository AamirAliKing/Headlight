package com.example.retailoclient;

import androidx.appcompat.app.AppCompatActivity;

import android.app.PendingIntent;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.IntentSender;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.gms.auth.api.credentials.Credential;
import com.google.android.gms.auth.api.credentials.Credentials;
import com.google.android.gms.auth.api.credentials.HintRequest;
import com.google.android.material.snackbar.Snackbar;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class SignupActivity extends AppCompatActivity {

    EditText etPhoneNumber, etName, etShopname, etAddress, etCNIC, etPassword;
    Button btnSignup;
    UUID uuid;

    String number = "";
    String name = "";
    String shopName = "";
    String address = "";
    String cnic = "";
    String pass = "";
    String location = "";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        etPhoneNumber = (EditText) findViewById(R.id.et_phone_num_forgot);
        etName = (EditText) findViewById(R.id.et_name);
        etShopname = (EditText) findViewById(R.id.et_shop_name);
        etAddress = (EditText) findViewById(R.id.et_shop_address);
        etCNIC = (EditText) findViewById(R.id.et_cnic);
        etPassword = (EditText) findViewById(R.id.et_password);
        btnSignup = (Button) findViewById(R.id.btn_signup);

        try {
            numberCheckin();
        } catch (Exception e) {
            e.printStackTrace();
        }

        etPhoneNumber.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (etPhoneNumber.getText().toString().equals("")) {
                    numberCheckin();
                }
            }
        });

        btnSignup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                uuid = UUID.randomUUID();
                name = etName.getText().toString();
                shopName = etShopname.getText().toString();
                address = etAddress.getText().toString();
                cnic = etCNIC.getText().toString();
                pass = etPassword.getText().toString();
                location = "----";
                String numberr = etPhoneNumber.getText().toString();


                if (numberr.isEmpty()) {
                    etPhoneNumber.setError("enter the number");

                } else {
                    if (name.isEmpty()) {

                        etName.setError("enter the name");

                    } else {
                        if (shopName.isEmpty()) {
                            etShopname.setError("enter the shopname");

                        } else {
                            if (address.isEmpty()) {
                                etAddress.setError("enter the Address");

                            } else {

                                if (cnic.isEmpty()) {
                                    etCNIC.setError("enter the CNIC");

                                } else {

                                    if (pass.isEmpty()) {

                                        etPassword.setError("enter the password");

                                    } else {

                                        if (numberr.equals(number)) {

                                            signUp(uuid.toString().substring(0, 8), etPhoneNumber.getText().toString(), name, shopName, address, cnic, location, pass);
                                            etPhoneNumber.setText("");
                                            etName.setText("");
                                            etShopname.setText("");
                                            etAddress.setText("");
                                            etCNIC.setText("");
                                            etPassword.setText("");
                                            location = "";
                                        }else {
                                            Snackbar.make(btnSignup,"Failed! Please Enter your own number",Snackbar.LENGTH_LONG).show();
                                        }
                                    }
                                }

                            }
                        }

                    }
                }
            }
        });
    }

    public void signUp(final String id, final String num, final String name, final String shopName, final String address, final String cnic, final String location, final String password) {

        final ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("please wait , Signing up");
        progressDialog.show();
        StringRequest signupRequest = new StringRequest(StringRequest.Method.POST, "http://headlight.pk/test/signup.php", new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                progressDialog.dismiss();

                if (response.toString().equals("0")){
                    Toast.makeText(getApplicationContext(), "user already exists", Toast.LENGTH_LONG).show();
                }else if (response.toString().equals("1")){
                    Toast.makeText(getApplicationContext(), "signup success", Toast.LENGTH_LONG).show();
                    startActivity(new Intent(SignupActivity.this,LoginActivity.class));
                    }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                progressDialog.dismiss();

                Toast.makeText(getApplicationContext(), "Something went wrong", Toast.LENGTH_SHORT).show();
            }
        }) {

            @Override
            protected Map<String, String> getParams() throws AuthFailureError {

                Map<String, String> params = new HashMap<String, String>();
               // params.put("id", id);
                params.put("cellno", num);
                params.put("username", name);
                params.put("shopname", shopName);
                params.put("address", address);
                params.put("cnic", cnic);
               // params.put("loc", location);
                params.put("password", password);

                return params;
            }
        };

        RequestQueue signUpRequesQueue = Volley.newRequestQueue(this);
        signUpRequesQueue.add(signupRequest);
    }


    private void numberCheckin() {
        HintRequest hintRequest = new HintRequest.Builder()
                .setPhoneNumberIdentifierSupported(true)
                .build();

        PendingIntent intent = Credentials.getClient(this).getHintPickerIntent(hintRequest);
        try {
            startIntentSenderForResult(intent.getIntentSender(),
                    1, null, 0, 0, 0);
        } catch (IntentSender.SendIntentException e) {
            e.printStackTrace();
        }
    }


    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode) {
            case 1:
                // Obtain the phone number from the result
                if (resultCode == RESULT_OK) {
                    Credential credential = data.getParcelableExtra(Credential.EXTRA_KEY);

                    number = credential.getId().toString();
                    number="0"+number.substring(3);
                    etPhoneNumber.setText(number);

                }
                break;
            // ...
        }
    }

}