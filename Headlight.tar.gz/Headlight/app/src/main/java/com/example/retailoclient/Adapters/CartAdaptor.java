package com.example.retailoclient.Adapters;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.AuthFailureError;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.retailoclient.CartActivity;
import com.example.retailoclient.Models.CartProduct;
import com.example.retailoclient.ProductsActivity;
import com.example.retailoclient.R;
import com.google.android.material.snackbar.Snackbar;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CartAdaptor extends RecyclerView.Adapter<CartAdaptor.ViewHolder> {

    List<CartProduct> list;
    private int subproductQty=1;
    Context context;
    Button btnrm;

    public CartAdaptor(List<CartProduct> list) {
        this.list = list;
    }

    public class ViewHolder extends RecyclerView.ViewHolder{

        ImageView imgCartProduct;
        TextView txtCartProductname;
        TextView txtCartBrand;
        TextView txtCartQty;
        TextView txtCartPrice;
        Button btnRemoveItem;
        public ViewHolder(@NonNull View itemView) {

            super(itemView);

            btnRemoveItem=(Button)itemView.findViewById(R.id.btn_cartitem_remove);
            imgCartProduct=(ImageView)itemView.findViewById(R.id.img_cart_product);
            txtCartProductname=(TextView)itemView.findViewById(R.id.txt_cartproduct);
            txtCartBrand=(TextView)itemView.findViewById(R.id.txt_cart_brand);
            txtCartQty=(TextView)itemView.findViewById(R.id.txt_cart_qty);
            txtCartPrice=(TextView)itemView.findViewById(R.id.txt_cart_unit_price);
            btnrm=btnRemoveItem;
            btnRemoveItem.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    String status= list.get(getAdapterPosition()).getStatus();
                    if (!status.equals("reserved")){
                            removeItemFromCart(list.get(getAdapterPosition()).getProductname());
                            context.startActivity(new Intent(context, CartActivity.class));
                    }else {
                        Snackbar.make(btnRemoveItem,"you can't remove this item these resered no for you",Snackbar.LENGTH_LONG).show();
                    }
                }
            });
        }
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        context=parent.getContext();
        View cartView= LayoutInflater.from(parent.getContext()).inflate(R.layout.cart_subproduct_row,parent,false);

      ViewHolder viewHolder=new ViewHolder(cartView);

        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.imgCartProduct.setImageBitmap(list.get(position).getProductimg());
        holder.txtCartProductname.setText(list.get(position).getProductname());
        holder.txtCartBrand.setText(list.get(position).getCatname());
        holder.txtCartPrice.setText(list.get(position).getProductPrice()+"");
        holder.txtCartQty.setText(list.get(position).getProductQty()+"");

       // subproductQty=list.get(position).getCartProductQty();
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    private void removeItemFromCart(final String productname) {

        final ProgressDialog progressDialog=new ProgressDialog(context);
        progressDialog.setMessage("deleting current item from list");
        progressDialog.setCancelable(false);
        progressDialog.show();
        StringRequest stringRequest= new StringRequest(StringRequest.Method.POST, "http://headlight.pk/test/removeitem.php", new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                progressDialog.dismiss();
                Snackbar.make(btnrm, response.toString(), Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
                    //    context.startActivity(new Intent(context,CartActivity.class));

            }

        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                Toast.makeText(context.getApplicationContext(),"Something went wrong",Toast.LENGTH_SHORT).show();
                progressDialog.dismiss();
            }
        }){

            @Override
            protected Map<String, String> getParams() throws AuthFailureError {

                Map<String,String> params=new HashMap<String, String>();
                params.put("username", ProductsActivity.name);
                params.put("productname",productname);

                return params;
            }
        };

        RequestQueue requestQueue= Volley.newRequestQueue(context);
        requestQueue.add(stringRequest);

    }

}


