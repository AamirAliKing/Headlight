package com.example.retailoclient;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.snackbar.Snackbar;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class ForgotPasswordActivity extends AppCompatActivity {

    EditText etNumber,etPassword,etPasswordConfirm;
    Button btnResetpassword;
    String number;
    String password;
    String confirmPass;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgot_password);

        etPassword=(EditText)findViewById(R.id.et_password_forgot);
        etPasswordConfirm=(EditText)findViewById(R.id.et_password_forgot_confirm);
        btnResetpassword=(Button)findViewById(R.id.btn_resetPassword);

       number= getIntent().getExtras().getString("number");
       //number=etNumber.getText().toString();

       btnResetpassword.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {

               password=etPassword.getText().toString();
               confirmPass=etPasswordConfirm.getText().toString();

               if (!password.isEmpty() && !confirmPass.isEmpty()){

                        if (password.equals(confirmPass)){
                            resetPassword(number,password);
                        }else{

                            Snackbar.make(btnResetpassword,"Password not match", Snackbar.LENGTH_LONG).show();
                        }
               }else {
                   Snackbar.make(btnResetpassword,"Fill the Fields", Snackbar.LENGTH_LONG).show();
               }
           }
       });
    }

    private void resetPassword(String cellno,String newPassword) {

        final ProgressDialog progressDialog =new ProgressDialog(this);
        progressDialog.setMessage("please wait");
        progressDialog.show();
        StringRequest loginRequest=new StringRequest(StringRequest.Method.POST, "http://headlight.pk/test/resetPassword.php", new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                Toast.makeText(getApplicationContext(),response.toString(),Toast.LENGTH_LONG).show();

                Intent intent = new Intent(ForgotPasswordActivity.this, LoginActivity.class);
                startActivity(intent);
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                progressDialog.dismiss();
                Log.d("error", error.toString());
                Toast.makeText(getApplicationContext(),"Something went wrong",Toast.LENGTH_SHORT).show();
            }
        }){

            @Override
            protected Map<String, String> getParams() throws AuthFailureError {

                Map<String,String> params=new HashMap<String, String>();
                params.put("cellno",number);
                params.put("password",password);

                return params;
            }
        };

        RequestQueue signUpRequesQueue= Volley.newRequestQueue(this);
        signUpRequesQueue.add(loginRequest);
    }
}