package com.example.retailoclient.Adapters;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.util.Base64;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.AuthFailureError;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.retailoclient.CartDetailsAcivity;
import com.example.retailoclient.Models.CartProduct;
import com.example.retailoclient.ProductsActivity;
import com.example.retailoclient.R;
import com.example.retailoclient.Models.SubProducts;
import com.example.retailoclient.SubProductsActivity;

import java.io.ByteArrayOutputStream;
import java.io.FileOutputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class SubProductAdaptor extends RecyclerView.Adapter<SubProductAdaptor.ViewHolder> {

    Context context;
    int subproductQty = 1;
    List<SubProducts> mSubProducts;
    final UUID uuid=UUID.randomUUID();
    final String id=uuid.toString().substring(0,8);


    public SubProductAdaptor(List<SubProducts> subProducts) {
        mSubProducts = subProducts;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        ImageView imgSubProduct;
        TextView txtSubProduct;
        TextView txtBrand;
        TextView txtSubProductQTY;
        TextView txtSubProductPrice;
        Button btnAddtocart;

        public ViewHolder(@NonNull final Context context, View itemView) {

            super(itemView);

            imgSubProduct = (ImageView) itemView.findViewById(R.id.img_subproduct);
            txtSubProduct = (TextView) itemView.findViewById(R.id.txt_subproduct);
            txtBrand = (TextView) itemView.findViewById(R.id.txt_brand);
            txtSubProductPrice = (TextView) itemView.findViewById(R.id.txt_subproduct_price);
            txtSubProductQTY = (TextView) itemView.findViewById(R.id.txt_subproduct_qty);
            btnAddtocart = (Button) itemView.findViewById(R.id.btn_addtocart);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    gotocartDetailsActivity(getAdapterPosition());
                }
            });


            btnAddtocart.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    gotocartDetailsActivity(getAdapterPosition());

                }
            });
        }
    }


    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        this.context=parent.getContext();
        View subProductsView = LayoutInflater.from(parent.getContext()).inflate(R.layout.subproduct_row, parent, false);
        ViewHolder viewHolder = new ViewHolder(parent.getContext(), subProductsView);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        ImageView imgSubProduct = holder.imgSubProduct;
        TextView txtSubProduct = holder.txtSubProduct;
        TextView txtBrand = holder.txtBrand;
        TextView txtSubProductQTY = holder.txtSubProductQTY;
        TextView txtSubProductPrice = holder.txtSubProductPrice;

        imgSubProduct.setImageBitmap(mSubProducts.get(position).getImgSubProduct());
        txtSubProduct.setText(mSubProducts.get(position).getSubProductName());
        txtBrand.setText(mSubProducts.get(position).getBrand() + "");
        txtSubProductPrice.setText(mSubProducts.get(position).getPrice() + "");
        txtSubProductQTY.setText(mSubProducts.get(position).getSubProductQuantity() + "");
    }

    @Override
    public int getItemCount() {
        return mSubProducts.size();
    }


    private void gotocartDetailsActivity(int pos) {

        Intent intent=new Intent(context, CartDetailsAcivity.class);
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        mSubProducts.get(pos).getImgSubProduct().compress(Bitmap.CompressFormat.JPEG, 100, bytes);
        intent.putExtra("productimg",bytes.toByteArray());
        intent.putExtra("productname",mSubProducts.get(pos).getSubProductName());
        intent.putExtra("catname",mSubProducts.get(pos).getBrand());
        intent.putExtra("productqty",mSubProducts.get(pos).getSubProductQuantity());
        intent.putExtra("productprice",mSubProducts.get(pos).getPrice());

        context.startActivity(intent);

    }

}