package com.example.retailoclient;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.snackbar.Snackbar;

import java.io.ByteArrayOutputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class CartDetailsAcivity extends AppCompatActivity implements View.OnClickListener  {

    Button btnAddtoCartDetails;
    ImageButton btnIncrease,btnDecrease;
    TextView txtProductname,txtCat,txtQty,txtPrice;
    ImageView imgProduct;

    Bitmap bitmap;
    String productname;
    String catname;
    int productprice=1;
    int productqty=1;

    int finalqty=1;
    int finalprice=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cart_details_acivity);

        btnAddtoCartDetails=(Button)findViewById(R.id.btn_addtocart_details);
        btnIncrease=(ImageButton)findViewById(R.id.btn_increase);
        btnDecrease=(ImageButton)findViewById(R.id.btn_decrease);
        imgProduct=(ImageView)findViewById(R.id.img_product_details);
        txtProductname=(TextView)findViewById(R.id.txt_product_name_details);
        txtCat=(TextView)findViewById(R.id.txt_category_details);
        txtQty=(TextView)findViewById(R.id.txt_qty_details);
        txtPrice=(TextView)findViewById(R.id.txt_price_details);

        if (getIntent().getExtras()!=null) {
            productname = getIntent().getStringExtra("productname");
            catname = getIntent().getStringExtra("catname");
            byte[] bytes = getIntent().getByteArrayExtra("productimg");
            productqty = getIntent().getIntExtra("productqty", 1);
            finalprice=productprice=getIntent().getIntExtra("productprice",1);
            bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);

        }
        imgProduct.setImageBitmap(bitmap);
        txtProductname.setText(productname);
        txtCat.setText(catname);
        txtQty.setText(finalqty+"");
        txtPrice.setText(productprice+"");



        btnIncrease.setOnClickListener(this);
        btnDecrease.setOnClickListener(this);
        btnAddtoCartDetails.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {

        switch (v.getId()){

            case R.id.btn_increase:
                if (finalqty<productqty) {
                    finalqty += 1;
                    finalprice = productprice * finalqty;
                    txtQty.setText(finalqty+"");
                    txtPrice.setText(finalprice+"");
                }
                break;

            case R.id.btn_decrease:
                if (finalqty>1){
                    finalqty -= 1;
                    finalprice = productprice * finalqty;
                    txtQty.setText(finalqty+"");
                    txtPrice.setText(finalprice+"");
                }
                break;

            case R.id.btn_addtocart_details:

                addTocart((UUID.randomUUID().toString()).substring(0,8),bitmap,productname,catname,finalqty,finalprice);

                break;
        }
    }


    private void addTocart(final String orderid, final Bitmap bitmap, final String productname, final String catname, final int finalqty, final int finalprice) {

         final ProgressDialog progressDialog=new ProgressDialog(this);
        progressDialog.setMessage("adding to cart");
        progressDialog.show();
        progressDialog.setCancelable(false);
        StringRequest stringRequest = new StringRequest(StringRequest.Method.POST, "http://headlight.pk/test/sendToCart.php",
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        progressDialog.dismiss();
                        Snackbar.make(btnAddtoCartDetails,response.toString(), Snackbar.LENGTH_LONG)
                                .setAction("Goto to Cart", new View.OnClickListener() {
                                    @Override
                                    public void onClick(View v) {
                                        startActivity(new Intent(CartDetailsAcivity.this,CartActivity.class));
                                    }
                                }).show();

                    //    Log.d("img", response.toString());
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
             //   Log.d("sendtocartt: ",error.toString());
                progressDialog.dismiss();
                Toast.makeText(getApplicationContext(),"Something went wrong",Toast.LENGTH_SHORT).show();
                //  Log.d("cartt", "error");

            }
        }){

            @Override
            protected Map<String, String> getParams() throws AuthFailureError {

                Map<String,String> params=new <String,String>HashMap();

                ByteArrayOutputStream stream = new ByteArrayOutputStream();
                bitmap.compress(Bitmap.CompressFormat.PNG, 50, stream); //compress to which format you want.
                byte [] byte_arr = stream.toByteArray();
                String image_str = Base64.encodeToString(byte_arr, Base64.DEFAULT);

                //  Log.d("img", image_str+"");

                params.put("id",orderid);
                params.put("username",ProductsActivity.name);
                params.put("productimg",image_str);
                params.put("productname",productname);

                params.put("cat",catname);
                params.put("productqty",finalqty+"");
                params.put("productprice",finalprice+"");
                params.put("status","");

                return params;
            }
        };


        RequestQueue requestQueue= Volley.newRequestQueue(getApplicationContext());
        requestQueue.add(stringRequest);
    }

}