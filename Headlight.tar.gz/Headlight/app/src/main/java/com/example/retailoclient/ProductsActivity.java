package com.example.retailoclient;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.app.ProgressDialog;
import android.app.SearchManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.SearchView;
import android.widget.TextView;
import android.widget.Toast;
import com.android.volley.AuthFailureError;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.retailoclient.Adapters.NewArrivalsAdaptor;
import com.example.retailoclient.Adapters.ProductAdapter;
import com.example.retailoclient.Models.Product;
import com.example.retailoclient.Models.SubProducts;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.navigation.NavigationView;
import com.google.android.material.snackbar.Snackbar;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.example.retailoclient.SubProductsActivity.catnam;

public class ProductsActivity extends AppCompatActivity {

    TextView txtcountitemscart;
    FloatingActionButton btnCartHistory;
    List<Product> products;
    public static Map<String,Bitmap> imgesForCartList=new HashMap<String, Bitmap>();

    RecyclerView productsList;
    RecyclerView newArrivalsList;

    ProductAdapter productAdapter;
    NewArrivalsAdaptor newArrivalsAdaptor;

    String countitemscart= String.valueOf(0);


//    public static List<SubProducts> cartSubProducts;

    public static String name=null;
    public static String id;
    public static String number;
    public static String catName;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_profile);

        //Adding custom toolbar
        Toolbar toolbar=(Toolbar)findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowTitleEnabled(false);

        btnCartHistory=(FloatingActionButton)findViewById(R.id.btnCartHistoryInProducts);
        txtcountitemscart=(TextView)findViewById(R.id.txt_item_count_inproducts);
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.nav_view);
        newArrivalsList=(RecyclerView)findViewById(R.id.recycler_new_arrivals);
        productsList=(RecyclerView)findViewById(R.id.recycler);

        products=new ArrayList<Product>();

        if (name==null) {
            name = getIntent().getExtras().getString("name");
            id = getIntent().getExtras().getString("id");
            number = getIntent().getExtras().getString("number");
        }

//      retieving products from server
        retrieveDataFromServer();

//      counting cartitems history
        getCartItemscount();

        getimagesForCart();

        // new Arrivals items
        newArrivalsAdaptor=new NewArrivalsAdaptor(products);
        newArrivalsList.setHasFixedSize(true);
        newArrivalsList.setAdapter(newArrivalsAdaptor);
        newArrivalsList.setLayoutManager(new LinearLayoutManager(this,LinearLayoutManager.HORIZONTAL,false));

       //regular items
        productAdapter=new ProductAdapter(products);
        productsList.setHasFixedSize(true);
        productsList.setAdapter(productAdapter);
        productsList.setLayoutManager(new GridLayoutManager(getApplicationContext(),2));

        btnCartHistory.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            Intent intent = new Intent(ProductsActivity.this, CartActivity.class);
                startActivity(intent);
            }
        });


        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()){

                    case R.id.nav_cart:

                        Intent intent = new Intent(ProductsActivity.this, CartActivity.class);
                        startActivity(intent);

                    break;
                    case R.id.nav_logout:
                        name=null;
                        startActivity(new Intent(ProductsActivity.this,LoginActivity.class));
                        finish();

                        break;
                }

                return false;
            }
        });
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main,menu);

        SearchManager searchManager= (SearchManager) getSystemService(SEARCH_SERVICE);
        SearchView searchView=(SearchView)menu.findItem(R.id.app_bar_search).getActionView();
        searchView.setSearchableInfo(searchManager.getSearchableInfo(getComponentName()));
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {

                if (query.equals("")) {

                    retrieveDataFromServer();

                } else {
                    Toast.makeText(getApplicationContext(), query + "", Toast.LENGTH_SHORT).show();
                    retrieveDataFromServer(query + "");

                 }

                return true;
            }
            @Override
            public boolean onQueryTextChange(String newText) {

                if (newText.equals("")) {

                    retrieveDataFromServer();
                }
                  return true;
            }
        });


        return true;
    }


    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        int id=item.getItemId();

        switch (id){

            case R.id.app_bar_logout:

                Toast.makeText(getApplicationContext(),"loging out",Toast.LENGTH_SHORT).show();
                startActivity(new Intent(ProductsActivity.this,LoginActivity.class));
                finish();
                break;

            case R.id.app_bar_refresh:

                retrieveDataFromServer();

                break;
        }

        return true;
    }

    public void retrieveDataFromServer(){

        products.clear();
        final ProgressDialog progressDialog=new ProgressDialog(this);
        progressDialog.setMessage("loading data");
        progressDialog.show();

        StringRequest stringRequest=new StringRequest(StringRequest.Method.POST, "http://headlight.pk/test/getCategoryProducts.php",
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        progressDialog.dismiss();
                        try {

                            JSONObject jsonObject = new JSONObject(response);
                            JSONArray jsonArray=jsonObject.getJSONArray("data");

                            for (int x=0; x<jsonArray.length(); x++){

                                JSONObject jsonObject2=jsonArray.getJSONObject(x);
                                String productName=jsonObject2.getString("productname");
                                String encodedImage=jsonObject2.getString("productimg");
                                byte[] decodedString = Base64.decode(encodedImage, Base64.DEFAULT);
                                Bitmap decodedimg = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
                                products.add(new Product(productName,decodedimg));
                                productAdapter.notifyDataSetChanged();
                                newArrivalsAdaptor.notifyDataSetChanged();
                            }

                        }catch (JSONException e){
                            progressDialog.dismiss();
                            e.printStackTrace();

                        }

                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                progressDialog.dismiss();
                Toast.makeText(getApplicationContext(),"error in loading"+"",Toast.LENGTH_SHORT).show();
            }
        });

        RequestQueue requestQueue= Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }

    public void retrieveDataFromServer(final String query){
        products.clear();
        final ProgressDialog progressDialog=new ProgressDialog(this);
        progressDialog.setMessage("loading data");
        progressDialog.show();
        StringRequest stringRequest=new StringRequest(StringRequest.Method.POST, "http://headlight.pk/test/search.php",
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        progressDialog.dismiss();
                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            JSONArray jsonArray=jsonObject.getJSONArray("data");
                            Log.d("check", jsonObject.toString());
                            for (int x=0; x<jsonArray.length(); x++){

                                JSONObject jsonObject2=jsonArray.getJSONObject(x);
                                catName=jsonObject2.getString("productname");
                                String encodedImage=jsonObject2.getString("productimg");

                                byte[] decodedString = Base64.decode(encodedImage, Base64.DEFAULT);
                                BitmapFactory.Options options=new BitmapFactory.Options();
                                options.outWidth=320;
                                options.outHeight=480;
                                Bitmap decodedimg = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length,options);
                                products.add(new Product(catName,decodedimg));
                                productAdapter.notifyDataSetChanged();
                            }

                        }catch (JSONException e){
                            progressDialog.dismiss();
                            e.printStackTrace();
                        }

                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                progressDialog.dismiss();
                Toast.makeText(getApplicationContext(),"error in loading"+"",Toast.LENGTH_SHORT).show();
            }
        }){

            @Override
            protected Map<String, String> getParams() throws AuthFailureError {

                Map<String,String> params=new HashMap<String, String>();
                params.put("query",query);
                return params;
            }
        };
        RequestQueue requestQueue= Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }

    @Override
    public void onBackPressed() {

    }


    public  void getCartItemscount(){

        StringRequest stringRequest= new StringRequest(StringRequest.Method.POST, "http://headlight.pk/test/countcartitems.php", new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                countitemscart=response.toString();
                txtcountitemscart.setText(countitemscart+"");
            }

        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        }){

            @Override
            protected Map<String, String> getParams() throws AuthFailureError {

                Map<String,String> params=new HashMap<String, String>();
                params.put("username",ProductsActivity.name);
                return params;
            }
        };

        RequestQueue requestQueue=Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);

    }


    public void getimagesForCart() {

        StringRequest stringRequest = new StringRequest(StringRequest.Method.POST, "http://headlight.pk/test/getProducts.php",
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            JSONArray jsonArray = jsonObject.getJSONArray("data");
                            Log.d("result1", jsonObject.toString());

                            for (int x = 0; x < jsonArray.length(); x++) {

                                JSONObject jsonObject2 = jsonArray.getJSONObject(x);
                                String subProductName = jsonObject2.getString("productname");
                                String encodedImage = jsonObject2.getString("productimg");
                                byte[] decodedString = Base64.decode(encodedImage, Base64.DEFAULT);
                                BitmapFactory.Options options=new BitmapFactory.Options();
                                options.outWidth=320;
                                options.outHeight=480;
                                Bitmap bitmap = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length, options);

                                // Log.d("results",  ""+subProductName+" : "+": encoded image  : "+encodedImage);

                                imgesForCartList.put(subProductName, bitmap);
                            }

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                Toast.makeText(getApplicationContext(), "error in loading" + "", Toast.LENGTH_SHORT).show();

            }
        }) {

            @Override
            protected Map<String, String> getParams() throws AuthFailureError {

                Map<String, String> params = new HashMap<String, String>();
                params.put("category", "");
                return params;

            }
        };

        RequestQueue requestQueue=Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);


    }

}