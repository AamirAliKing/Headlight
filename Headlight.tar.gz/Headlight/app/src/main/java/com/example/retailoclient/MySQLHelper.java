package com.example.retailoclient;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

import androidx.annotation.Nullable;

class MySQLHelper extends SQLiteOpenHelper {

    Context context;
    public static final String DBNAME="ProductsDB";
    public static final int DATABASE_VERSION=1;
    public static final String DB_TABLE="products";
    public static final String ID="id";
    public static final String PRODUCT_NAME="productname";
    public static final String PRODUCT_IMAGE="productimg";
    public static final String SQL_QUERY="CREATE TABLE "+DB_TABLE+"("+ID+" integer primary key autoincrement not null" +
            ", "+PRODUCT_IMAGE+" BLOB, "+PRODUCT_NAME+" text )";

    public MySQLHelper(Context context) {
        super(context, DBNAME, null, DATABASE_VERSION);
        this.context=context;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        createDatabase(db);
    }


    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }


    private void createDatabase(SQLiteDatabase db) {
            db.execSQL(SQL_QUERY);
    }

    public void insertData(int img,String name){
        ContentValues contentValues=new ContentValues();
        contentValues.put(PRODUCT_NAME,name);
        contentValues.put(PRODUCT_IMAGE,img);
        long id=getWritableDatabase().insert(DB_TABLE,null,contentValues);

        if(id!=-1){

            Toast.makeText(context.getApplicationContext(),"Data Inserted Successfully",Toast.LENGTH_SHORT).show();

        }
    }

    public Cursor retrieveData(){

        Cursor cursor;
        SQLiteDatabase database=getReadableDatabase();
        cursor=database.query(DB_TABLE,null,null,null,null,null,null);
        return cursor;
    }
}
