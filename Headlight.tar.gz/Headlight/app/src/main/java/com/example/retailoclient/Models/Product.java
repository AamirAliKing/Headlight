package com.example.retailoclient.Models;

import android.graphics.Bitmap;

public class Product {
    String productName;
    Bitmap productImg;

    public Product(String productName, Bitmap productImg) {
        this.productName = productName;
        this.productImg = productImg;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public Bitmap getProductImg() {
        return productImg;
    }

    public void setProductImg(Bitmap productImg) {
        this.productImg = productImg;
    }
}

